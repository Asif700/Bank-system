#include<conio.h>
#include<stdio.h>
#include<iostream>
using namespace std;
void custs();
struct bank
{
    string name;
    int id;
    float baln;
    char nam[20];
}c[10];
int main()
{
    int i;
    for(i=0;i<10;i++)
    {
        cout<<"Enter"<<i+1<<"Customer details\n";
        cout<<"Enter name:"
        cin>>c[i].nam;
        cout<<"Enter Account number: ";
        cin>>c[i].id;
        cout<<"Enter balance: ";
        cin>>[i].baln;
        cout<<"\n";
    }
    custs();
    getch();
}
void custs()
{
    int i;
    cout<<":customer Details:\n";
    for(i=0;i<10;i++)
    {
        if(c[i].bain<5000)
        {
            cout<<"Name is: "<<c[i].nam<<endl;
             cout<<"customer acc no "<<c[i].id<<endl;
            cout<<"customer balance is :"<<c.[i]balnc<endl;
            count<<endl;
        }
    }
}
